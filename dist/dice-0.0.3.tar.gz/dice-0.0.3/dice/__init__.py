#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# File Name: dice/__init__.py
# Author: Tate_fan
# mail: tate_fan@163.com
# Created Time: 2015年06月01日 星期一 15时28分06秒
# ======================================================================
__version__ = '0.0.3'
